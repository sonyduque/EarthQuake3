package com.example.earthquakemonitor.api

enum class ApiResponseStatus{
    DONE, LOADING, ERROR
}

class ApiResponse(var status: ApiResponseStatus = ApiResponseStatus.DONE)