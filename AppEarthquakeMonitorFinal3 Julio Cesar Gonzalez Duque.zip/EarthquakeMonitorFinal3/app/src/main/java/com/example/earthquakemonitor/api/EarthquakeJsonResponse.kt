package com.example.earthquakemonitor.api

class EarthquakeJsonResponse(val features: MutableList<Feature>)
