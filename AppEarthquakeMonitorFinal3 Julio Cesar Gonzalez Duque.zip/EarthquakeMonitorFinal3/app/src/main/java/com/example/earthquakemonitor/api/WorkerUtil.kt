package com.example.earthquakemonitor.api
import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

object WorkerUtil{
    fun sheduleSync(context: Context){
        val constraint=Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val syncRequest =
            PeriodicWorkRequestBuilder<SyncWorkManager>(1, TimeUnit.HOURS)
                .setConstraints(constraint)
                .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            SyncWorkManager.WORK_NAME,ExistingPeriodicWorkPolicy.KEEP, syncRequest)
    }

}