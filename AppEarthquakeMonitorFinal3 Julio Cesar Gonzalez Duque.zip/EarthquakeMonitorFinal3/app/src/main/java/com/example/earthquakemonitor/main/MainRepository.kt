package com.example.earthquakemonitor.main

import androidx.lifecycle.LiveData
import com.example.earthquakemonitor.Earthquake
import com.example.earthquakemonitor.api.EarthquakeJsonResponse
import com.example.earthquakemonitor.api.EarthquakesApi
import com.example.earthquakemonitor.database.EqDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainRepository(private val database: EqDatabase) {

    suspend fun fetchEarthquakes(sortByMagnitude: Boolean): MutableList<Earthquake> {
        return withContext(Dispatchers.IO) {
            val eqJsonResponse = service.getLastHourEarthquakes()
            val eqList = parseEqResult(eqJsonResponse)

            database.eqDao.insertAll(eqList)

            fetchEarthquakesFromDb(sortByMagnitude)
        }
    }

    suspend fun fetchEarthquakesFromDb(sortByMagnitude: Boolean): MutableList<Earthquake>{
        return withContext(Dispatchers.IO) {
            if (sortByMagnitude) {
                database.eqDao.getEarthquakesByMagnitude()
            } else {
                database.eqDao.getEarthquakes()
            }
        }
    }
    private fun parseEqResult(eqJsonResponse: EarthquakeJsonResponse): MutableList<Earthquake>{
        val eqList = mutableListOf<Earthquake>()
        val featureList =eqJsonResponse.features

        for (feature in featureList) {
            val id = feature.id
            val place = feature.properties.place
            val magnitude = feature.properties.mag
            val time = feature.properties.time
            val latitude = feature.geometry.latitude
            val longitude = feature.geometry.longitude
            val earthquake = Earthquake(id, place, magnitude, time, latitude, longitude)
            eqList.add(earthquake)
        }

        return eqList
    }
}